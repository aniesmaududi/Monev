-- phpMyAdmin SQL Dump
-- version 3.3.7deb5build0.10.10.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jan 22, 2012 at 08:16 PM
-- Server version: 5.1.49
-- PHP Version: 5.3.3-1ubuntu9.5

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `db_monev_final`
--

-- --------------------------------------------------------

--
-- Table structure for table `t_dept`
--

CREATE TABLE IF NOT EXISTS `t_dept` (
  `kddept` varchar(3) DEFAULT NULL,
  `nmdept` varchar(70) DEFAULT NULL,
  `updater` varchar(100) DEFAULT NULL,
  `tglupdate` datetime DEFAULT NULL,
  KEY `kddept` (`kddept`,`nmdept`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `t_giat`
--

CREATE TABLE IF NOT EXISTS `t_giat` (
  `kdgiat` varchar(6) DEFAULT NULL,
  `nmgiat` varchar(200) DEFAULT NULL,
  `kddept` varchar(11) DEFAULT NULL,
  `kdunit` varchar(6) DEFAULT NULL,
  `kdprogram` varchar(9) DEFAULT NULL,
  `updater` varchar(100) DEFAULT NULL,
  `tglupdate` datetime DEFAULT NULL,
  KEY `kdgiat` (`kdgiat`,`nmgiat`,`kddept`,`kdunit`,`kdprogram`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `t_ikk`
--

CREATE TABLE IF NOT EXISTS `t_ikk` (
  `kdgiat` varchar(6) DEFAULT NULL,
  `kdikk` varchar(5) DEFAULT NULL,
  `nmikk` varchar(250) DEFAULT NULL,
  `updater` varchar(100) DEFAULT NULL,
  `tglupdate` datetime DEFAULT NULL,
  KEY `kdgiat` (`kdgiat`,`kdikk`,`nmikk`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `t_iku`
--

CREATE TABLE IF NOT EXISTS `t_iku` (
  `kddept` varchar(6) DEFAULT NULL,
  `kdunit` varchar(6) DEFAULT NULL,
  `kdprogram` varchar(9) DEFAULT NULL,
  `kdiku` varchar(5) DEFAULT NULL,
  `nmiku` varchar(250) DEFAULT NULL,
  `updater` varchar(28) DEFAULT NULL,
  `tglupdate` varchar(61) DEFAULT NULL,
  KEY `kddept` (`kddept`,`kdunit`,`kdprogram`,`kdiku`,`nmiku`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `t_kabkota`
--

CREATE TABLE IF NOT EXISTS `t_kabkota` (
  `kdlokasi` varchar(2) DEFAULT NULL,
  `kdkabkota` varchar(2) DEFAULT NULL,
  `nmkabkota` varchar(32) DEFAULT NULL,
  `updater` varchar(100) DEFAULT NULL,
  `tglupdate` datetime DEFAULT NULL,
  KEY `kdlokasi` (`kdlokasi`,`kdkabkota`,`nmkabkota`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `t_lokasi`
--

CREATE TABLE IF NOT EXISTS `t_lokasi` (
  `kdlokasi` varchar(2) DEFAULT NULL,
  `nmlokasi` varchar(31) DEFAULT NULL,
  `region` varchar(13) DEFAULT NULL,
  `updater` varchar(100) DEFAULT NULL,
  `tglupdate` datetime DEFAULT NULL,
  KEY `kdlokasi` (`kdlokasi`,`nmlokasi`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `t_output`
--

CREATE TABLE IF NOT EXISTS `t_output` (
  `kdgiat` varchar(6) DEFAULT NULL,
  `kdoutput` varchar(8) DEFAULT NULL,
  `nmoutput` varchar(200) DEFAULT NULL,
  `sat` varchar(38) DEFAULT NULL,
  `updater` varchar(8) DEFAULT NULL,
  `tglupdate` varchar(9) DEFAULT NULL,
  KEY `kdgiat` (`kdgiat`,`kdoutput`,`nmoutput`,`sat`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `t_program`
--

CREATE TABLE IF NOT EXISTS `t_program` (
  `kddept` varchar(3) DEFAULT NULL,
  `kdunit` varchar(2) DEFAULT NULL,
  `kdprogram` varchar(2) DEFAULT NULL,
  `nmprogram` varchar(139) DEFAULT NULL,
  `uroutcome` varchar(250) DEFAULT NULL,
  `updater` varchar(100) DEFAULT NULL,
  `tglupdate` datetime DEFAULT NULL,
  KEY `kddept` (`kddept`,`kdunit`,`kdprogram`,`nmprogram`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `t_satker`
--

CREATE TABLE IF NOT EXISTS `t_satker` (
  `kdsatker` varchar(8) DEFAULT NULL,
  `nmsatker` varchar(121) DEFAULT NULL,
  `kddept` varchar(16) DEFAULT NULL,
  `kdunit` varchar(12) DEFAULT NULL,
  `kdlokasi` varchar(8) DEFAULT NULL,
  `kdkabkota` varchar(9) DEFAULT NULL,
  `updater` int(2) DEFAULT NULL,
  `tglupdate` int(2) DEFAULT NULL,
  KEY `kdsatker` (`kdsatker`,`nmsatker`,`kddept`,`kdunit`,`kdlokasi`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `t_unit`
--

CREATE TABLE IF NOT EXISTS `t_unit` (
  `kddept` varchar(3) DEFAULT NULL,
  `kdunit` varchar(2) DEFAULT NULL,
  `nmunit` varchar(70) DEFAULT NULL,
  `updater` varchar(100) DEFAULT NULL,
  `tglupdate` datetime DEFAULT NULL,
  KEY `kddept` (`kddept`,`kdunit`,`nmunit`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
